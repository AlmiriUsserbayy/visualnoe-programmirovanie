
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Parent root = fxmlLoader.load();
        stage.setTitle("Расчёт стоимости покупки");
        stage.setScene(new Scene(root, 420, 300));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
